﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace App2
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();

            YourImageControl.Source = ImageSource.FromResource("App2.OrangeIcon.png");
        }
        private async void OnNextButtonClicked(object sender, EventArgs e)
        {
            App8.MainPage childAppPage = new App8.MainPage();
            await Navigation.PushAsync(childAppPage);

        }
    }
}
