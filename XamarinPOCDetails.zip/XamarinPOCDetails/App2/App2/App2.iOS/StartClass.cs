﻿using System;
using UIKit;
using Foundation;
using IosApp.iOS;
using System.Collections.Generic;

using Xamarin.Forms;
using SystemConfiguration;
using CoreGraphics;
 


using Xamarin.Forms.Platform.iOS;
 

namespace App2.iOS
{
    public class StartClass : UIViewController
    {
        public override void ViewDidLoad()
        {
            base.ViewDidLoad();

            View.BackgroundColor = UIColor.White;

            var stackLayout = new UIStackView
            {
                TranslatesAutoresizingMaskIntoConstraints = false,
                Axis = UILayoutConstraintAxis.Vertical,
                Alignment = UIStackViewAlignment.Center,
                Distribution = UIStackViewDistribution.Fill,
                Spacing = 10
            };
        

            var imageControlCellde = new UIImageView
            {
                TranslatesAutoresizingMaskIntoConstraints = false,
                Image = UIImage.FromBundle("OrangeIcon1.png"),
                ContentMode = UIViewContentMode.ScaleAspectFit,
                //HeightAnchor.ConstraintEqualTo(70).Active = true
            };



            // Define height constraint
            NSLayoutConstraint heightConstraint = NSLayoutConstraint.Create(imageControlCellde, NSLayoutAttribute.Height, NSLayoutRelation.Equal, null, NSLayoutAttribute.NoAttribute, 1, 70); // Replace '100' with the desired height value

            // Define width constraint
            NSLayoutConstraint widthConstraint = NSLayoutConstraint.Create(imageControlCellde, NSLayoutAttribute.Width, NSLayoutRelation.Equal, null, NSLayoutAttribute.NoAttribute, 1, 70); // Replace '200' with the desired width value

            // Add the constraints to the UIImageView
            imageControlCellde.AddConstraints(new[] { heightConstraint, widthConstraint });

            // Set the position of the UIImageView using other constraints (e.g., leading and top constraints)
            //NSLayoutConstraint.ActivateConstraints(new NSLayoutConstraint[]
            //{
            //    imageControlCellde.LeadingAnchor.ConstraintEqualTo(View.LeadingAnchor, 20), // Set the leading constraint with 20 points margin
            //    imageControlCellde.TopAnchor.ConstraintEqualTo(View.TopAnchor, 100) // Set the top constraint with 100 points margin
            //});


            var label1 = new UILabel
            {
                TranslatesAutoresizingMaskIntoConstraints = false,
                Text = "Please click to proceed to open child app",
                TextColor = UIColor.Black,
                TextAlignment = UITextAlignment.Center
            };

            var button = new UIButton
            {
                TranslatesAutoresizingMaskIntoConstraints = false,
                BackgroundColor = UIColor.FromRGB(0, 123, 255)
            };

            // Define height constraint
            NSLayoutConstraint heightConstraint1 = NSLayoutConstraint.Create(button, NSLayoutAttribute.Height, NSLayoutRelation.Equal, null, NSLayoutAttribute.NoAttribute, 1, 50); // Replace '100' with the desired height value

            // Define width constraint
            NSLayoutConstraint widthConstraint1 = NSLayoutConstraint.Create(button, NSLayoutAttribute.Width, NSLayoutRelation.Equal, null, NSLayoutAttribute.NoAttribute, 1, 150); // Replace '200' with the desired width value

            // Add the constraints to the UIImageView
            button.AddConstraints(new[] { heightConstraint1, widthConstraint1 });


            button.SetTitle("Open Child App", UIControlState.Normal);
            button.SetTitleColor(UIColor.Yellow, UIControlState.Normal);
            //button.TouchUpInside += OnNextButtonClicked;
            button.AddTarget(OnNextButtonClicked, UIControlEvent.TouchUpInside);

            var dynamicLabel = new UILabel
            {
                TranslatesAutoresizingMaskIntoConstraints = false,
                Text = "------------",
                TextColor = UIColor.FromRGB(255, 215, 0),
                TextAlignment = UITextAlignment.Center
            };

            stackLayout.AddArrangedSubview(imageControlCellde);
            stackLayout.AddArrangedSubview(label1);
            stackLayout.AddArrangedSubview(button);
            stackLayout.AddArrangedSubview(dynamicLabel);

            View.AddSubview(stackLayout);

            stackLayout.CenterXAnchor.ConstraintEqualTo(View.CenterXAnchor).Active = true;
            stackLayout.CenterYAnchor.ConstraintEqualTo(View.CenterYAnchor).Active = true;
        }


        private async void OnNextButtonClicked(object sender, EventArgs e)
        {
            // Handle button click event

            var contentPage = new YourContentViewController();
            NavigationController.PushViewController(contentPage, true);

        }
    }
}